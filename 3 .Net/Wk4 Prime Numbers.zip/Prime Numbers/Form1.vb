﻿Public Class Form1

    Function IsPrime(ByVal intNum As Integer) As Boolean
        Dim intCount As Integer
        Dim blnAnswer As Boolean

        blnAnswer = True
        'Sets 2 as a prime number
        If intNum = 2 Then
            blnAnswer = True
        Else
            'counter goes from 2 to the square root of number you want to check is prime
            For intCount = 2 To Math.Sqrt(intNum)
                If intNum Mod intCount = 0 Then 'If remainder of number you're checking divided by counter is 0
                    blnAnswer = False 'return false and exit for
                    Exit For
                End If ' end if statement
            Next ' end for
        End If

        Return blnAnswer

    End Function

    Private Sub btnCheckIfPrime_Click(sender As Object, e As EventArgs) Handles btnCheckIfPrime.Click
        Dim intNumberEntry As Integer
        Dim blnTestIfPrime As Boolean ' set boolean to true
        If Integer.TryParse(txtNumEntry.Text, intNumberEntry) Then ' set entry as integer if number
            blnTestIfPrime = IsPrime(intNumberEntry) ' Test if number is prime using function
            If blnTestIfPrime = True Then
                lblPrimeDisp.Text = intNumberEntry & " is prime."
            Else
                lblPrimeDisp.Text = intNumberEntry & " is not prime."
            End If
        Else
            lblPrimeDisp.Text = "Please enter an integer :)"
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtNumEntry.Clear()
        lblPrimeDisp.Text = String.Empty
        txtNumEntry.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
