﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNumEntry = New System.Windows.Forms.TextBox()
        Me.btnCheckIfPrime = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblPrimeDisp = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(31, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(358, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Type a number below to test if it's prime:"
        '
        'txtNumEntry
        '
        Me.txtNumEntry.Location = New System.Drawing.Point(36, 66)
        Me.txtNumEntry.Name = "txtNumEntry"
        Me.txtNumEntry.Size = New System.Drawing.Size(353, 22)
        Me.txtNumEntry.TabIndex = 1
        Me.txtNumEntry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnCheckIfPrime
        '
        Me.btnCheckIfPrime.Location = New System.Drawing.Point(36, 136)
        Me.btnCheckIfPrime.Name = "btnCheckIfPrime"
        Me.btnCheckIfPrime.Size = New System.Drawing.Size(90, 33)
        Me.btnCheckIfPrime.TabIndex = 2
        Me.btnCheckIfPrime.Text = "Check"
        Me.btnCheckIfPrime.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(167, 136)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(90, 33)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(299, 136)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(90, 33)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblPrimeDisp
        '
        Me.lblPrimeDisp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPrimeDisp.Location = New System.Drawing.Point(36, 101)
        Me.lblPrimeDisp.Name = "lblPrimeDisp"
        Me.lblPrimeDisp.Size = New System.Drawing.Size(353, 23)
        Me.lblPrimeDisp.TabIndex = 5
        Me.lblPrimeDisp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCheckIfPrime
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(438, 202)
        Me.Controls.Add(Me.lblPrimeDisp)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCheckIfPrime)
        Me.Controls.Add(Me.txtNumEntry)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Prime Numbers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtNumEntry As TextBox
    Friend WithEvents btnCheckIfPrime As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblPrimeDisp As Label
End Class
