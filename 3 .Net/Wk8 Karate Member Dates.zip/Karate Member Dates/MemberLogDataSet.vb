﻿Partial Class MemberLogDataSet
End Class

Namespace MemberLogDataSetTableAdapters
    Partial Public Class MembersTableAdapter
    End Class
End Namespace
