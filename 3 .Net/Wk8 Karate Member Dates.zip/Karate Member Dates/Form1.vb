﻿Public Class Form1
    Private Sub dtpChooseDate_ValueChanged(sender As Object, e As EventArgs) Handles dtpChooseDate.ValueChanged
        Me.MembersTableAdapter.Fill(Me.MemberLogDataSet.Members, dtpChooseDate.Value)
    End Sub
End Class
