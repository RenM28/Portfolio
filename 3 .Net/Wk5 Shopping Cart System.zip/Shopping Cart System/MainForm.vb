﻿Public Class MainForm
    'initialized variables for each value to be printed in labels
    Dim decSubTotal As Decimal = 0
    Dim decTax As Decimal = 0
    Dim decShipping As Decimal = 0
    Dim decTotal As Decimal = 0

    Private Sub mnuFileReset_Click(sender As Object, e As EventArgs) Handles mnuFileReset.Click
        lstShoppingCart.Items.Clear() 'clears cart list
        'clears labels
        lblShipping.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty
        'sets variables to 0
        decSubTotal = 0
        decTax = 0
        decShipping = 0
        decTotal = 0
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close() 'closes form
    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        MessageBox.Show("Add Books to Your Shopping Cart and Find Price Total") 'Description
    End Sub

    Private Sub mnuProductsPrint_Click(sender As Object, e As EventArgs) Handles mnuProductsPrint.Click
        Dim frmPrint As New PrintBooksForm
        frmPrint.ShowDialog() 'shows user print books form

        'if price is not 0 (as long as user did not hit close button on print book form) the following will execute
        If g_decPRICE_TO_ADD <> 0 Then
            lstShoppingCart.Items.Add(g_strBOOK_TO_ADD) 'adds item to list

            'calculates all monetary values using functions written in cost module
            decSubTotal = CalcSubTotal(decSubTotal, g_decPRICE_TO_ADD)
            decTax = CalcTax(decSubTotal)
            decShipping = CalcShipping(lstShoppingCart.Items.Count)
            decTotal = CalcTotal(decSubTotal, decTax, decShipping)

            'sets labels to monetary values calculated
            lblSubtotal.Text = decSubTotal.ToString("c")
            lblTax.Text = decTax.ToString("c")
            lblShipping.Text = decShipping.ToString("c")
            lblTotal.Text = decTotal.ToString("c")
        End If
    End Sub

    Private Sub mnuProductsAudio_Click(sender As Object, e As EventArgs) Handles mnuProductsAudio.Click
        Dim frmAudio As New AudioBooksForm
        frmAudio.ShowDialog() 'shows user audio books form

        'if price is not 0 (as long as user did not hit close button on audio book form) the following will execute
        If g_decPRICE_TO_ADD <> 0 Then
            lstShoppingCart.Items.Add(g_strBOOK_TO_ADD) 'adds item to list

            'calculates all monetary values using functions written in cost module
            decSubTotal = CalcSubTotal(decSubTotal, g_decPRICE_TO_ADD)
            decTax = CalcTax(decSubTotal)
            decShipping = CalcShipping(lstShoppingCart.Items.Count)
            decTotal = CalcTotal(decSubTotal, decTax, decShipping)

            'sets labels to monetary values calculated
            lblSubtotal.Text = decSubTotal.ToString("c")
            lblTax.Text = decTax.ToString("c")
            lblShipping.Text = decShipping.ToString("c")
            lblTotal.Text = decTotal.ToString("c")
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lstShoppingCart.SelectedIndex <> -1 Then 'if item is selected
            Dim intCount As Integer 'initializes count variable
            For intCount = 0 To lstShoppingCart.Items.Count - 1 'iterates through all books in list
                If lstShoppingCart.SelectedIndex = intCount Then 'if selected item is at index
                    decShipping -= 2 'removes cost of shipping for item
                    'each if statement compares value of item selected to book titles
                    'the cost of the book that matches the selected item is subtracted from the subtotal
                    'the tax and overall total are then updated accordingly
                    If lstShoppingCart.Items(intCount) = g_strLEARN_CALCULUS_IN_ONE_DAY_AUDIO Or lstShoppingCart.Items(intCount) = g_strLEARN_CALCULUS_IN_ONE_DAY_PRINT Then
                        decSubTotal -= g_decLEARN_CALCULUS_IN_ONE_DAY
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    If lstShoppingCart.Items(intCount) = g_strHISTORY_OF_SCOTLAND_AUDIO Or lstShoppingCart.Items(intCount) = g_strHISTORY_OF_SCOTLAND_PRINT Then
                        decSubTotal -= g_decHISTORY_OF_SCOTLAND
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    If lstShoppingCart.Items(intCount) = g_strFEEL_THE_STRESS Then
                        decSubTotal -= g_decFEEL_THE_STRESS
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    If lstShoppingCart.Items(intCount) = g_strI_DID_IT_YOUR_WAY Then
                        decSubTotal -= g_decI_DID_IT_YOUR_WAY
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    If lstShoppingCart.Items(intCount) = g_strRELAXATION_TECHNIQUES Then
                        decSubTotal -= g_decRELAXATION_TECHNIQUES
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    If lstShoppingCart.Items(intCount) = g_strSCIENCE_OF_BODY_LANGUAGE Then
                        decSubTotal -= g_decSCIENCE_OF_BODY_LANGUAGE
                        decTax = CalcTax(decSubTotal)
                        decTotal = CalcTotal(decSubTotal, decTax, decShipping)
                    End If
                    lstShoppingCart.Items.Remove(lstShoppingCart.Items(intCount)) 'removes item from list
                    'updates what is displayed in labels
                    lblSubtotal.Text = decSubTotal.ToString("c")
                    lblTax.Text = decTax.ToString("c")
                    lblShipping.Text = decShipping.ToString("c")
                    lblTotal.Text = decTotal.ToString("c")
                End If
            Next
        Else
            MessageBox.Show("Please select item to remove.") 'reminds user to select an item before hitting remove
        End If
    End Sub
End Class
