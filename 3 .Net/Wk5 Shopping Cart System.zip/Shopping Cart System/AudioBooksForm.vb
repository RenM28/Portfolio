﻿Public Class AudioBooksForm
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstAudioBooks.SelectedIndex = 0 Then 'if user selects calc book
            g_strBOOK_TO_ADD = g_strLEARN_CALCULUS_IN_ONE_DAY_AUDIO 'changes title of book to add
            g_decPRICE_TO_ADD = g_decLEARN_CALCULUS_IN_ONE_DAY 'changes price to add
        End If
        If lstAudioBooks.SelectedIndex = 1 Then 'if user selects relaxation book
            g_strBOOK_TO_ADD = g_strRELAXATION_TECHNIQUES
            g_decPRICE_TO_ADD = g_decRELAXATION_TECHNIQUES
        End If
        If lstAudioBooks.SelectedIndex = 2 Then 'if user selects scotland book
            g_strBOOK_TO_ADD = g_strHISTORY_OF_SCOTLAND_AUDIO
            g_decPRICE_TO_ADD = g_decHISTORY_OF_SCOTLAND
        End If
        If lstAudioBooks.SelectedIndex = 3 Then 'if user selects science of body language book
            g_strBOOK_TO_ADD = g_strSCIENCE_OF_BODY_LANGUAGE
            g_decPRICE_TO_ADD = g_decSCIENCE_OF_BODY_LANGUAGE
        End If
        Me.Close() 'closes form
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        g_strBOOK_TO_ADD = String.Empty 'sets book to nothing
        g_decPRICE_TO_ADD = 0 'set price to 0
        Me.Close() 'closes form
    End Sub
End Class