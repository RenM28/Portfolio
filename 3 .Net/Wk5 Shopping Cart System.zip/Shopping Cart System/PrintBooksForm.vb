﻿Public Class PrintBooksForm
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstPrintBooks.SelectedIndex = 0 Then 'if user selects i did it your way book
            g_strBOOK_TO_ADD = g_strI_DID_IT_YOUR_WAY 'changes value of book to add
            g_decPRICE_TO_ADD = g_decI_DID_IT_YOUR_WAY 'changes price to add
        End If
        If lstPrintBooks.SelectedIndex = 1 Then 'if user selects scotland book
            g_strBOOK_TO_ADD = g_strHISTORY_OF_SCOTLAND_PRINT
            g_decPRICE_TO_ADD = g_decHISTORY_OF_SCOTLAND
        End If
        If lstPrintBooks.SelectedIndex = 2 Then 'if user selects calc book
            g_strBOOK_TO_ADD = g_strLEARN_CALCULUS_IN_ONE_DAY_PRINT
            g_decPRICE_TO_ADD = g_decLEARN_CALCULUS_IN_ONE_DAY
        End If
        If lstPrintBooks.SelectedIndex = 3 Then 'if user selects stress book
            g_strBOOK_TO_ADD = g_strFEEL_THE_STRESS
            g_decPRICE_TO_ADD = g_decFEEL_THE_STRESS
        End If
        Me.Close() 'closes form
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        g_strBOOK_TO_ADD = String.Empty 'sets book to nothing
        g_decPRICE_TO_ADD = 0 'sets price to 0
        Me.Close() 'closes form
    End Sub
End Class