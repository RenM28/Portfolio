﻿Module CostModule
    'intialized list of book prices
    Public g_decI_DID_IT_YOUR_WAY As Decimal = 11.95
    Public g_decHISTORY_OF_SCOTLAND As Decimal = 14.5
    Public g_decLEARN_CALCULUS_IN_ONE_DAY As Decimal = 29.95    'Also known as book of false promises
    Public g_decFEEL_THE_STRESS As Decimal = 18.5               'Don't need a book to do that
    Public g_decRELAXATION_TECHNIQUES As Decimal = 11.5
    Public g_decSCIENCE_OF_BODY_LANGUAGE As Decimal = 12.95

    'initialized names of books
    Public g_strI_DID_IT_YOUR_WAY As String = "I Did it Your Way        (Print)"
    Public g_strHISTORY_OF_SCOTLAND_PRINT As String = "The History of Scotland      (Print)"
    Public g_strLEARN_CALCULUS_IN_ONE_DAY_PRINT As String = "Learn Calculus in One Day      (Print)"
    Public g_strFEEL_THE_STRESS As String = "Feel the Stress        (Print)"
    Public g_strRELAXATION_TECHNIQUES As String = "Relaxation Techniques        (Audio)"
    Public g_strSCIENCE_OF_BODY_LANGUAGE As String = "Science of Body Language      (Audio)"
    Public g_strHISTORY_OF_SCOTLAND_AUDIO As String = "The History of Scotland      (Audio)"
    Public g_strLEARN_CALCULUS_IN_ONE_DAY_AUDIO As String = "Learn Calculus in One Day      (Audio)"

    'initializes variables that will keep track of items and prices added
    Public g_strBOOK_TO_ADD As String
    Public g_decPRICE_TO_ADD As Decimal

    Public g_decTAX_RATE As Decimal = 0.06 'tax rate
    Public g_decSHIPPING As Decimal = 2.0 'shipping rate

    'Inputs: current subtotal and price of book being added to the list
    'Output: subtotal including new price added
    Public Function CalcSubTotal(ByVal decSubTotal As Decimal, ByVal decAddOn As Decimal) As Decimal
        Return decSubTotal + decAddOn
    End Function

    'Input: subtotal with new price
    'Output: sales tax
    Public Function CalcTax(ByVal decSubTotal As Decimal) As Decimal
        Return decSubTotal * g_decTAX_RATE
    End Function

    'Input: number of items in shopping cart
    'Output: shipping for items
    Public Function CalcShipping(ByVal intNumItems As Integer) As Decimal
        Return intNumItems * g_decSHIPPING
    End Function

    'Inputs: subtotal, tax, and shipping
    'Output: total cost
    Public Function CalcTotal(ByVal decSubtotal As Decimal, ByVal decTax As Decimal, ByVal decShipping As Decimal) As Decimal
        Return decSubtotal + decTax + decShipping
    End Function
End Module
