﻿Public Class Main
    Inherits System.Web.UI.Page
    ' Function returns true if score is between 1 and 3 and false otherwise
    ' If false, shows user message that reminds them to enter only integer values from 1 to 3 in a specific textbox
    Private Function TestIfEntriesValid(ByVal intScore(,) As Integer) As Boolean
        Dim blnValidity As Boolean = True
        For i As Integer = 0 To 2
            For j As Integer = 0 To 3
                If intScore(i, j) < 1 Or intScore(i, j) > 3 Then
                    blnValidity = False
                    lblError.Text = "Please enter integer value between 1 and 3 for Boat " & i + 1 & " Race " & j + 1 & "."
                End If
            Next
        Next
        Return blnValidity
    End Function

    ' Function returns True if each row score adds to 6 and false otherwise
    ' If false, shows user message reminding them to enter the values 1, 2, and 3 somewhere in the row without repeat
    Private Function TestifRowTotalValid(ByVal intScore(,) As Integer) As Boolean
        Dim blnValidity As Boolean = True
        Dim intRowTotal(3) As Integer
        For i As Integer = 0 To 2
            intRowTotal(0) += intScore(i, 0)
            intRowTotal(1) += intScore(i, 1)
            intRowTotal(2) += intScore(i, 2)
            intRowTotal(3) += intScore(i, 3)
        Next
        For i As Integer = 0 To 3
            If intRowTotal(i) <> 6 Then
                blnValidity = False
                lblError.Text = "Please make sure to enter values 1, 2, and 3 without repeat in Row " & i + 1 & "."
            End If
        Next
        Return blnValidity
    End Function

    ' Function takes in 3 scores and compares their values
    ' The lowest score will receive the highest rank, while the highest score will receive the lowest rank
    ' Displays ranks in labels
    Private Sub CalcRank(ByVal intTotalScoreBoat1 As Integer, ByVal intTotalScoreBoat2 As Integer, ByVal intTotalScoreBoat3 As Integer)
        If intTotalScoreBoat1 < intTotalScoreBoat2 And intTotalScoreBoat1 < intTotalScoreBoat3 And intTotalScoreBoat2 < intTotalScoreBoat3 Then
            lblRank1.Text = "1"
            lblRank2.Text = "2"
            lblRank3.Text = "3"
        ElseIf intTotalScoreBoat1 < intTotalScoreBoat3 And intTotalScoreBoat1 < intTotalScoreBoat2 And intTotalScoreBoat3 < intTotalScoreBoat2 Then
            lblRank1.Text = "1"
            lblRank2.Text = "3"
            lblRank3.Text = "2"
        ElseIf intTotalScoreBoat2 < intTotalScoreBoat1 And intTotalScoreBoat2 < intTotalScoreBoat3 And intTotalScoreBoat1 < intTotalScoreBoat3 Then
            lblRank1.Text = "2"
            lblRank2.Text = "1"
            lblRank3.Text = "3"
        ElseIf intTotalScoreBoat3 < intTotalScoreBoat1 And intTotalScoreBoat3 < intTotalScoreBoat2 And intTotalScoreBoat1 < intTotalScoreBoat2 Then
            lblRank1.Text = "2"
            lblRank2.Text = "3"
            lblRank3.Text = "1"
        ElseIf intTotalScoreBoat3 < intTotalScoreBoat2 And intTotalScoreBoat3 < intTotalScoreBoat1 And intTotalScoreBoat2 < intTotalScoreBoat1 Then
            lblRank1.Text = "3"
            lblRank2.Text = "2"
            lblRank3.Text = "1"
        ElseIf intTotalScoreBoat2 < intTotalScoreBoat3 And intTotalScoreBoat2 < intTotalScoreBoat1 And intTotalScoreBoat3 < intTotalScoreBoat1 Then
            lblRank1.Text = "3"
            lblRank2.Text = "1"
            lblRank3.Text = "2"
        Else
            ' If there is a tie all 3 ranks will be marked as null and user will see "TIE" in label at bottom of form
            lblRank1.ForeColor = System.Drawing.Color.Red
            lblRank2.ForeColor = System.Drawing.Color.Red
            lblRank3.ForeColor = System.Drawing.Color.Red
            lblRank1.Text = "NULL"
            lblRank2.Text = "NULL"
            lblRank3.Text = "NULL"
            lblError.Text = "TIE"
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim intTotalScoreBoat1, intTotalScoreBoat2, intTotalScoreBoat3 As Integer
        Try
            ' Clears total labels
            lblTotal1.Text = String.Empty
            lblTotal2.Text = String.Empty
            lblTotal3.Text = String.Empty

            ' Clears error bar
            lblError.Text = String.Empty

            ' Clears rank labels
            lblRank1.Text = String.Empty
            lblRank2.Text = String.Empty
            lblRank3.Text = String.Empty

            ' Sets rank labels back to black
            lblRank1.ForeColor = System.Drawing.Color.Black
            lblRank2.ForeColor = System.Drawing.Color.Black
            lblRank3.ForeColor = System.Drawing.Color.Black

            ' Initializes all boat scores as an array if they can be converted to integers
            Dim intBoatScores(,) As Integer =
                {{CInt(txtB1R1.Text), CInt(txtB1R2.Text), CInt(txtB1R3.Text), CInt(txtB1R4.Text)},
                 {CInt(txtB2R1.Text), CInt(txtB2R2.Text), CInt(txtB2R3.Text), CInt(txtB2R4.Text)},
                 {CInt(txtB3R1.Text), CInt(txtB3R2.Text), CInt(txtB3R3.Text), CInt(txtB3R4.Text)}}

            ' If all places entered are between 1 and 3, the code will run
            If TestIfEntriesValid(intBoatScores) Then
                ' If all rows add up to 6, the code will run
                If TestifRowTotalValid(intBoatScores) Then

                    ' Calculates total score for each of the three boats
                    For j As Integer = 0 To 3
                        intTotalScoreBoat1 += intBoatScores(0, j)
                        intTotalScoreBoat2 += intBoatScores(1, j)
                        intTotalScoreBoat3 += intBoatScores(2, j)
                    Next

                    ' Calls function that will calc rank of each boat overall based on total scores and display them to rank labels
                    CalcRank(intTotalScoreBoat1, intTotalScoreBoat2, intTotalScoreBoat3)

                    ' Displays total score in labels
                    lblTotal1.Text = intTotalScoreBoat1.ToString()
                    lblTotal2.Text = intTotalScoreBoat2.ToString()
                    lblTotal3.Text = intTotalScoreBoat3.ToString()
                End If
            End If

        Catch ex As Exception
            lblError.Text = "Make sure to enter all integer values."
        End Try
    End Sub

    Protected Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears boat 1 values
        txtB1R1.Text = String.Empty
        txtB1R2.Text = String.Empty
        txtB1R3.Text = String.Empty
        txtB1R4.Text = String.Empty

        ' Clears boat 2 values
        txtB2R1.Text = String.Empty
        txtB2R2.Text = String.Empty
        txtB2R3.Text = String.Empty
        txtB2R4.Text = String.Empty

        ' Clears boat 3 values
        txtB3R1.Text = String.Empty
        txtB3R2.Text = String.Empty
        txtB3R3.Text = String.Empty
        txtB3R4.Text = String.Empty

        ' Clears error label
        lblError.Text = String.Empty

        ' Clears total labels
        lblTotal1.Text = String.Empty
        lblTotal2.Text = String.Empty
        lblTotal3.Text = String.Empty

        ' Clears rank labels
        lblRank1.Text = String.Empty
        lblRank2.Text = String.Empty
        lblRank3.Text = String.Empty

        ' Sets rank labels back to black
        lblRank1.ForeColor = System.Drawing.Color.Black
        lblRank2.ForeColor = System.Drawing.Color.Black
        lblRank3.ForeColor = System.Drawing.Color.Black

        ' Sets focus to first box
        txtB1R1.Focus()
    End Sub
End Class