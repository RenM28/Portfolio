﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtEntry5 = New System.Windows.Forms.TextBox()
        Me.txtEntry4 = New System.Windows.Forms.TextBox()
        Me.txtEntry3 = New System.Windows.Forms.TextBox()
        Me.txtEntry2 = New System.Windows.Forms.TextBox()
        Me.txtEntry1 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblFourth = New System.Windows.Forms.Label()
        Me.lblFirst = New System.Windows.Forms.Label()
        Me.lblSecond = New System.Windows.Forms.Label()
        Me.lblFifth = New System.Windows.Forms.Label()
        Me.lblThird = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(186, 134)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(73, 39)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(9, 134)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(73, 39)
        Me.btnSubmit.TabIndex = 12
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtEntry5)
        Me.GroupBox1.Controls.Add(Me.txtEntry4)
        Me.GroupBox1.Controls.Add(Me.txtEntry3)
        Me.GroupBox1.Controls.Add(Me.txtEntry2)
        Me.GroupBox1.Controls.Add(Me.txtEntry1)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 72)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(250, 58)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Try your luck at the lottery!"
        '
        'txtEntry5
        '
        Me.txtEntry5.Location = New System.Drawing.Point(197, 22)
        Me.txtEntry5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEntry5.Name = "txtEntry5"
        Me.txtEntry5.Size = New System.Drawing.Size(44, 20)
        Me.txtEntry5.TabIndex = 19
        '
        'txtEntry4
        '
        Me.txtEntry4.Location = New System.Drawing.Point(150, 22)
        Me.txtEntry4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEntry4.Name = "txtEntry4"
        Me.txtEntry4.Size = New System.Drawing.Size(44, 20)
        Me.txtEntry4.TabIndex = 18
        '
        'txtEntry3
        '
        Me.txtEntry3.Location = New System.Drawing.Point(103, 22)
        Me.txtEntry3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEntry3.Name = "txtEntry3"
        Me.txtEntry3.Size = New System.Drawing.Size(44, 20)
        Me.txtEntry3.TabIndex = 17
        '
        'txtEntry2
        '
        Me.txtEntry2.Location = New System.Drawing.Point(56, 22)
        Me.txtEntry2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEntry2.Name = "txtEntry2"
        Me.txtEntry2.Size = New System.Drawing.Size(44, 20)
        Me.txtEntry2.TabIndex = 16
        '
        'txtEntry1
        '
        Me.txtEntry1.Location = New System.Drawing.Point(8, 22)
        Me.txtEntry1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEntry1.Name = "txtEntry1"
        Me.txtEntry1.Size = New System.Drawing.Size(44, 20)
        Me.txtEntry1.TabIndex = 15
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblFourth)
        Me.GroupBox2.Controls.Add(Me.lblFirst)
        Me.GroupBox2.Controls.Add(Me.lblSecond)
        Me.GroupBox2.Controls.Add(Me.lblFifth)
        Me.GroupBox2.Controls.Add(Me.lblThird)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 10)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(250, 58)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lottery Numbers"
        '
        'lblFourth
        '
        Me.lblFourth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFourth.Location = New System.Drawing.Point(150, 22)
        Me.lblFourth.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFourth.Name = "lblFourth"
        Me.lblFourth.Size = New System.Drawing.Size(43, 19)
        Me.lblFourth.TabIndex = 10
        Me.lblFourth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblFirst
        '
        Me.lblFirst.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFirst.Location = New System.Drawing.Point(8, 22)
        Me.lblFirst.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFirst.Name = "lblFirst"
        Me.lblFirst.Size = New System.Drawing.Size(43, 19)
        Me.lblFirst.TabIndex = 7
        Me.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSecond
        '
        Me.lblSecond.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSecond.Location = New System.Drawing.Point(56, 22)
        Me.lblSecond.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSecond.Name = "lblSecond"
        Me.lblSecond.Size = New System.Drawing.Size(43, 19)
        Me.lblSecond.TabIndex = 8
        Me.lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblFifth
        '
        Me.lblFifth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFifth.Location = New System.Drawing.Point(197, 22)
        Me.lblFifth.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFifth.Name = "lblFifth"
        Me.lblFifth.Size = New System.Drawing.Size(43, 19)
        Me.lblFifth.TabIndex = 11
        Me.lblFifth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblThird
        '
        Me.lblThird.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblThird.Location = New System.Drawing.Point(103, 22)
        Me.lblThird.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblThird.Name = "lblThird"
        Me.lblThird.Size = New System.Drawing.Size(43, 19)
        Me.lblThird.TabIndex = 9
        Me.lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(97, 134)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(73, 39)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Clear"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(273, 188)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtEntry5 As TextBox
    Friend WithEvents txtEntry4 As TextBox
    Friend WithEvents txtEntry3 As TextBox
    Friend WithEvents txtEntry2 As TextBox
    Friend WithEvents txtEntry1 As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblFourth As Label
    Friend WithEvents lblFirst As Label
    Friend WithEvents lblSecond As Label
    Friend WithEvents lblFifth As Label
    Friend WithEvents lblThird As Label
    Friend WithEvents Button1 As Button
End Class
