﻿Module DigitsModule
    Public g_intDIGITS_MATCHED As Integer = 0
End Module
