﻿Public Class MainForm
    Dim intDigitsMatched As Integer = 0         'Keeps track of number of matching digits

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim frmLottery As New LotteryForm           'Creates new form that will display only if user wins
        Const intMAX_SUBSCRIPT As Integer = 4       'Maximum subscript
        Dim intLottery(intMAX_SUBSCRIPT) As Integer 'Lottery array
        Dim intCount As Integer                     'Loop counter
        Dim rand As New Random                      'Creates a random object

        intDigitsMatched = 0 'initializes digits matched to 0

        'Fill the array with random numbers (each number will be in the range 0-9)
        For intCount = 0 To intMAX_SUBSCRIPT
            intLottery(intCount) = rand.Next(10)
        Next

        'Display array elements in labels
        lblFirst.Text = intLottery(0).ToString()
        lblSecond.Text = intLottery(1).ToString()
        lblThird.Text = intLottery(2).ToString()
        lblFourth.Text = intLottery(3).ToString()
        lblFifth.Text = intLottery(4).ToString()

        Try
            Dim intEntries() As Integer = {txtEntry1.Text, txtEntry2.Text, txtEntry3.Text, txtEntry4.Text, txtEntry5.Text}
            For intCount = 0 To intEntries.Length - 1
                If intEntries(intCount) >= 0 And intEntries(intCount) <= 9 Then
                    If intEntries(intCount) = intLottery(intCount) Then
                        intDigitsMatched += 1
                    End If
                Else
                    MessageBox.Show("Please only enter values between 0 and 9.")
                    intDigitsMatched = 11
                    Exit For
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Please enter only integer values.")
            intDigitsMatched = 11
        End Try

        If intDigitsMatched = 5 Then
            frmLottery.ShowDialog()
        ElseIf intDigitsMatched = 1 Then
            MessageBox.Show("You matched " & intDigitsMatched & " digit. Better luck next time!")
        ElseIf intDigitsMatched <> 11 Then
            MessageBox.Show("You matched " & intDigitsMatched & " digits. Better luck next time!")
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtEntry1.Clear()
        txtEntry2.Clear()
        txtEntry3.Clear()
        txtEntry4.Clear()
        txtEntry5.Clear()
        txtEntry1.Focus()
        intDigitsMatched = 0
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
