﻿Public Class WebForm1
    Inherits System.Web.UI.Page
    Const decTAX_RATE As Decimal = 0.08D   ' Tax Rate

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Get today's date from system and display it
        lblDateToday.Text = Now.ToString("D")

        ' Get the current time from system and display it
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Protected Sub btnCalculateCharges_Click(sender As Object, e As EventArgs) Handles btnCalculateCharges.Click
        ' Variables for calculations
        Dim decRoomCharges As Decimal   ' Room charge total
        Dim decAddCharges As Decimal    ' Additional charges
        Dim decSubtotal As Decimal      ' Subtotal
        Dim decTax As Decimal           ' Tax
        Dim decTotal As Decimal         ' Total for all charges
        Try
            ' Calc and display room charges
            decRoomCharges = CDec(txtNights.Text) * CDec(txtNightCharge.Text)
            lblRoomCharges.Text = decRoomCharges.ToString("c")

            ' Calc and display additional charges
            decAddCharges = CDec(txtRoomService.Text) + CDec(txtTelephone.Text) + CDec(txtMisc.Text)
            lblAdditionalCharges.Text = decAddCharges.ToString("c")

            ' Calc and display subtotal
            decSubtotal = decRoomCharges + decAddCharges
            lblSubtotal.Text = decSubtotal.ToString("c")

            ' Calc and display tax
            decTax = decSubtotal * decTAX_RATE
            lblTax.Text = decTax.ToString("c")

            ' Calc and display total charges
            decTotal = decSubtotal + decTax
            lblTotalCharges.Text = decTotal.ToString("c")

            ' Clears error message
            lblError.Text = String.Empty

        Catch ex As Exception
            ' Error message
            lblError.Text = "All input must be valid numeric values."
        End Try
    End Sub

    Protected Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear room info fields
        txtNightCharge.Text = String.Empty
        txtNights.Text = String.Empty

        ' Clear additional charge fields
        txtRoomService.Text = String.Empty
        txtTelephone.Text = String.Empty
        txtMisc.Text = String.Empty

        ' Clear the decTotal fields
        lblRoomCharges.Text = String.Empty
        lblAdditionalCharges.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotalCharges.Text = String.Empty

        ' Get today's date from operating system and display it
        lblDateToday.Text = Now.ToString("D")

        ' Get current time from operating system and display it
        lblTimeToday.Text = Now.ToString("T")

        'Reset focus to first field
        txtNights.Text = String.Empty

        'Clear error message
        lblError.Text = String.Empty
    End Sub
End Class