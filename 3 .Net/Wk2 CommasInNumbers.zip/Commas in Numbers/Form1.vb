﻿Public Class Form1
    Private Sub btnDispSinCommas_Click(sender As Object, e As EventArgs) Handles btnDispSinCommas.Click
        Dim strNum3Commas As String = txtNum.Text
        Dim strNum2Commas, strNum1Comma, strNum0Commas As String
        Dim position1, position2, position3, position4 As Integer
        position1 = strNum3Commas.IndexOf(",", 0)
        If position1 <> -1 Then
            strNum2Commas = strNum3Commas.Remove(position1, 1)
            position2 = strNum2Commas.IndexOf(",", position1)
            If position2 <> -1 Then
                strNum1Comma = strNum2Commas.Remove(position2, 1)
                position3 = strNum1Comma.IndexOf(",", position2)
                If position3 <> -1 Then
                    strNum0Commas = strNum1Comma.Remove(position3, 1)
                    position4 = strNum0Commas.IndexOf(",", position3)
                    If position4 <> -1 Then
                        lblNum.Text = "Please only use 3 commas or less."
                    Else
                        lblNum.Text = strNum0Commas
                    End If
                Else
                    lblNum.Text = strNum1Comma
                End If
            Else
                lblNum.Text = strNum2Commas
            End If
        Else
            lblNum.Text = strNum3Commas
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNum.Clear()
        lblNum.Text = String.Empty
        txtNum.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
