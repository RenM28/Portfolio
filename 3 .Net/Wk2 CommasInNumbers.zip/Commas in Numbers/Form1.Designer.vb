﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.txtNum = New System.Windows.Forms.TextBox()
        Me.lblNum = New System.Windows.Forms.Label()
        Me.btnDispSinCommas = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Location = New System.Drawing.Point(94, 20)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(294, 17)
        Me.lblDescription.TabIndex = 0
        Me.lblDescription.Text = "Enter a number with no more than 3 commas:"
        '
        'txtNum
        '
        Me.txtNum.Location = New System.Drawing.Point(157, 55)
        Me.txtNum.Name = "txtNum"
        Me.txtNum.Size = New System.Drawing.Size(170, 22)
        Me.txtNum.TabIndex = 1
        '
        'lblNum
        '
        Me.lblNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum.Location = New System.Drawing.Point(97, 85)
        Me.lblNum.Name = "lblNum"
        Me.lblNum.Size = New System.Drawing.Size(291, 23)
        Me.lblNum.TabIndex = 2
        Me.lblNum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnDispSinCommas
        '
        Me.btnDispSinCommas.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnDispSinCommas.Location = New System.Drawing.Point(65, 137)
        Me.btnDispSinCommas.Name = "btnDispSinCommas"
        Me.btnDispSinCommas.Size = New System.Drawing.Size(94, 31)
        Me.btnDispSinCommas.TabIndex = 3
        Me.btnDispSinCommas.Text = "Display"
        Me.btnDispSinCommas.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Location = New System.Drawing.Point(190, 137)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(94, 31)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Cl&ear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(310, 137)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(94, 31)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnDispSinCommas
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(481, 218)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDispSinCommas)
        Me.Controls.Add(Me.lblNum)
        Me.Controls.Add(Me.txtNum)
        Me.Controls.Add(Me.lblDescription)
        Me.Name = "Form1"
        Me.Text = "Commas In Numbers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDescription As Label
    Friend WithEvents txtNum As TextBox
    Friend WithEvents lblNum As Label
    Friend WithEvents btnDispSinCommas As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
