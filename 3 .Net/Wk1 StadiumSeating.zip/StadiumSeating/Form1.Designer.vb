﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpTicketsSold = New System.Windows.Forms.GroupBox()
        Me.txtNumClassCSold = New System.Windows.Forms.TextBox()
        Me.txtNumClassBSold = New System.Windows.Forms.TextBox()
        Me.txtNumClassASold = New System.Windows.Forms.TextBox()
        Me.lblClassC = New System.Windows.Forms.Label()
        Me.lblClassB = New System.Windows.Forms.Label()
        Me.lblClassA = New System.Windows.Forms.Label()
        Me.lblDirections = New System.Windows.Forms.Label()
        Me.grpRevGen = New System.Windows.Forms.GroupBox()
        Me.lblRevTotal = New System.Windows.Forms.Label()
        Me.lblRevClassC = New System.Windows.Forms.Label()
        Me.lblRevClassB = New System.Windows.Forms.Label()
        Me.lblRevClassA = New System.Windows.Forms.Label()
        Me.lblTotalRev = New System.Windows.Forms.Label()
        Me.lblClassCR = New System.Windows.Forms.Label()
        Me.lblClassBR = New System.Windows.Forms.Label()
        Me.lblClassAR = New System.Windows.Forms.Label()
        Me.btnCalcRevenue = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.grpTicketsSold.SuspendLayout()
        Me.grpRevGen.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpTicketsSold
        '
        Me.grpTicketsSold.Controls.Add(Me.txtNumClassCSold)
        Me.grpTicketsSold.Controls.Add(Me.txtNumClassBSold)
        Me.grpTicketsSold.Controls.Add(Me.txtNumClassASold)
        Me.grpTicketsSold.Controls.Add(Me.lblClassC)
        Me.grpTicketsSold.Controls.Add(Me.lblClassB)
        Me.grpTicketsSold.Controls.Add(Me.lblClassA)
        Me.grpTicketsSold.Controls.Add(Me.lblDirections)
        Me.grpTicketsSold.Location = New System.Drawing.Point(12, 12)
        Me.grpTicketsSold.Name = "grpTicketsSold"
        Me.grpTicketsSold.Size = New System.Drawing.Size(286, 193)
        Me.grpTicketsSold.TabIndex = 0
        Me.grpTicketsSold.TabStop = False
        Me.grpTicketsSold.Text = "Tickets Sold"
        '
        'txtNumClassCSold
        '
        Me.txtNumClassCSold.Location = New System.Drawing.Point(131, 140)
        Me.txtNumClassCSold.Name = "txtNumClassCSold"
        Me.txtNumClassCSold.Size = New System.Drawing.Size(100, 22)
        Me.txtNumClassCSold.TabIndex = 6
        '
        'txtNumClassBSold
        '
        Me.txtNumClassBSold.Location = New System.Drawing.Point(131, 113)
        Me.txtNumClassBSold.Name = "txtNumClassBSold"
        Me.txtNumClassBSold.Size = New System.Drawing.Size(100, 22)
        Me.txtNumClassBSold.TabIndex = 5
        '
        'txtNumClassASold
        '
        Me.txtNumClassASold.Location = New System.Drawing.Point(131, 86)
        Me.txtNumClassASold.Name = "txtNumClassASold"
        Me.txtNumClassASold.Size = New System.Drawing.Size(100, 22)
        Me.txtNumClassASold.TabIndex = 4
        '
        'lblClassC
        '
        Me.lblClassC.AutoSize = True
        Me.lblClassC.Location = New System.Drawing.Point(49, 143)
        Me.lblClassC.Name = "lblClassC"
        Me.lblClassC.Size = New System.Drawing.Size(59, 17)
        Me.lblClassC.TabIndex = 3
        Me.lblClassC.Text = "Class C:"
        '
        'lblClassB
        '
        Me.lblClassB.AutoSize = True
        Me.lblClassB.Location = New System.Drawing.Point(49, 116)
        Me.lblClassB.Name = "lblClassB"
        Me.lblClassB.Size = New System.Drawing.Size(59, 17)
        Me.lblClassB.TabIndex = 2
        Me.lblClassB.Text = "Class B:"
        '
        'lblClassA
        '
        Me.lblClassA.AutoSize = True
        Me.lblClassA.Location = New System.Drawing.Point(49, 89)
        Me.lblClassA.Name = "lblClassA"
        Me.lblClassA.Size = New System.Drawing.Size(59, 17)
        Me.lblClassA.TabIndex = 1
        Me.lblClassA.Text = "Class A:"
        '
        'lblDirections
        '
        Me.lblDirections.Location = New System.Drawing.Point(38, 34)
        Me.lblDirections.Name = "lblDirections"
        Me.lblDirections.Size = New System.Drawing.Size(213, 43)
        Me.lblDirections.TabIndex = 0
        Me.lblDirections.Text = "Enter the number of tickets sold for each class of seats"
        '
        'grpRevGen
        '
        Me.grpRevGen.Controls.Add(Me.lblRevTotal)
        Me.grpRevGen.Controls.Add(Me.lblRevClassC)
        Me.grpRevGen.Controls.Add(Me.lblRevClassB)
        Me.grpRevGen.Controls.Add(Me.lblRevClassA)
        Me.grpRevGen.Controls.Add(Me.lblTotalRev)
        Me.grpRevGen.Controls.Add(Me.lblClassCR)
        Me.grpRevGen.Controls.Add(Me.lblClassBR)
        Me.grpRevGen.Controls.Add(Me.lblClassAR)
        Me.grpRevGen.Location = New System.Drawing.Point(322, 12)
        Me.grpRevGen.Name = "grpRevGen"
        Me.grpRevGen.Size = New System.Drawing.Size(273, 193)
        Me.grpRevGen.TabIndex = 7
        Me.grpRevGen.TabStop = False
        Me.grpRevGen.Text = "Revenue Generated"
        '
        'lblRevTotal
        '
        Me.lblRevTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevTotal.Location = New System.Drawing.Point(145, 142)
        Me.lblRevTotal.Name = "lblRevTotal"
        Me.lblRevTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblRevTotal.TabIndex = 11
        '
        'lblRevClassC
        '
        Me.lblRevClassC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevClassC.Location = New System.Drawing.Point(145, 100)
        Me.lblRevClassC.Name = "lblRevClassC"
        Me.lblRevClassC.Size = New System.Drawing.Size(100, 23)
        Me.lblRevClassC.TabIndex = 10
        '
        'lblRevClassB
        '
        Me.lblRevClassB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevClassB.Location = New System.Drawing.Point(145, 66)
        Me.lblRevClassB.Name = "lblRevClassB"
        Me.lblRevClassB.Size = New System.Drawing.Size(100, 23)
        Me.lblRevClassB.TabIndex = 9
        '
        'lblRevClassA
        '
        Me.lblRevClassA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevClassA.Location = New System.Drawing.Point(145, 34)
        Me.lblRevClassA.Name = "lblRevClassA"
        Me.lblRevClassA.Size = New System.Drawing.Size(100, 23)
        Me.lblRevClassA.TabIndex = 8
        '
        'lblTotalRev
        '
        Me.lblTotalRev.AutoSize = True
        Me.lblTotalRev.Location = New System.Drawing.Point(17, 145)
        Me.lblTotalRev.Name = "lblTotalRev"
        Me.lblTotalRev.Size = New System.Drawing.Size(105, 17)
        Me.lblTotalRev.TabIndex = 7
        Me.lblTotalRev.Text = "Total Revenue:"
        '
        'lblClassCR
        '
        Me.lblClassCR.AutoSize = True
        Me.lblClassCR.Location = New System.Drawing.Point(63, 100)
        Me.lblClassCR.Name = "lblClassCR"
        Me.lblClassCR.Size = New System.Drawing.Size(59, 17)
        Me.lblClassCR.TabIndex = 3
        Me.lblClassCR.Text = "Class C:"
        '
        'lblClassBR
        '
        Me.lblClassBR.AutoSize = True
        Me.lblClassBR.Location = New System.Drawing.Point(63, 67)
        Me.lblClassBR.Name = "lblClassBR"
        Me.lblClassBR.Size = New System.Drawing.Size(59, 17)
        Me.lblClassBR.TabIndex = 2
        Me.lblClassBR.Text = "Class B:"
        '
        'lblClassAR
        '
        Me.lblClassAR.AutoSize = True
        Me.lblClassAR.Location = New System.Drawing.Point(63, 34)
        Me.lblClassAR.Name = "lblClassAR"
        Me.lblClassAR.Size = New System.Drawing.Size(59, 17)
        Me.lblClassAR.TabIndex = 1
        Me.lblClassAR.Text = "Class A:"
        '
        'btnCalcRevenue
        '
        Me.btnCalcRevenue.Location = New System.Drawing.Point(125, 227)
        Me.btnCalcRevenue.Name = "btnCalcRevenue"
        Me.btnCalcRevenue.Size = New System.Drawing.Size(154, 33)
        Me.btnCalcRevenue.TabIndex = 8
        Me.btnCalcRevenue.Text = "Calculate Revenue"
        Me.btnCalcRevenue.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(309, 227)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(86, 33)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Cl&ear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(424, 227)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(86, 33)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalcRevenue
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(625, 288)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalcRevenue)
        Me.Controls.Add(Me.grpRevGen)
        Me.Controls.Add(Me.grpTicketsSold)
        Me.Name = "Form1"
        Me.Text = "Stadium Seating"
        Me.grpTicketsSold.ResumeLayout(False)
        Me.grpTicketsSold.PerformLayout()
        Me.grpRevGen.ResumeLayout(False)
        Me.grpRevGen.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpTicketsSold As GroupBox
    Friend WithEvents lblDirections As Label
    Friend WithEvents lblClassC As Label
    Friend WithEvents lblClassB As Label
    Friend WithEvents lblClassA As Label
    Friend WithEvents txtNumClassCSold As TextBox
    Friend WithEvents txtNumClassBSold As TextBox
    Friend WithEvents txtNumClassASold As TextBox
    Friend WithEvents grpRevGen As GroupBox
    Friend WithEvents lblRevTotal As Label
    Friend WithEvents lblRevClassC As Label
    Friend WithEvents lblRevClassB As Label
    Friend WithEvents lblRevClassA As Label
    Friend WithEvents lblTotalRev As Label
    Friend WithEvents lblClassCR As Label
    Friend WithEvents lblClassBR As Label
    Friend WithEvents lblClassAR As Label
    Friend WithEvents btnCalcRevenue As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
