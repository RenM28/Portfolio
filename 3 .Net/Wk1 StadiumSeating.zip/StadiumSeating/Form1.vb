﻿Public Class Form1
    Const intCLASS_A_COST As Integer = 15
    Const intCLASS_B_COST As Integer = 12
    Const intCLASS_C_COST As Integer = 9

    Private Sub btnCalcRevenue_Click(sender As Object, e As EventArgs) Handles btnCalcRevenue.Click
        Try
            Dim intTicketsClassA, intTicketsClassB, intTicketsClassC, intRevClassA, intRevClassB, intRevClassC, intRevTotal As Integer
            intTicketsClassA = txtNumClassASold.Text
            intTicketsClassB = txtNumClassBSold.Text
            intTicketsClassC = txtNumClassCSold.Text
            intRevClassA = intTicketsClassA * intCLASS_A_COST
            intRevClassB = intTicketsClassB * intCLASS_B_COST
            intRevClassC = intTicketsClassC * intCLASS_C_COST
            intRevTotal = intRevClassA + intRevClassB + intRevClassC
            lblRevClassA.Text = intRevClassA.ToString("C")
            lblRevClassB.Text = intRevClassB.ToString("C")
            lblRevClassC.Text = intRevClassC.ToString("C")
            lblRevTotal.Text = intRevTotal.ToString("C")
        Catch ex As Exception
            MessageBox.Show("Please be sure to enter numeric values in all text boxes.")
            txtNumClassASold.Focus()
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNumClassASold.Clear()
        txtNumClassBSold.Clear()
        txtNumClassCSold.Clear()
        lblRevClassA.Text = ""
        lblRevClassB.Text = ""
        lblRevClassC.Text = ""
        lblRevTotal.Text = ""
        txtNumClassASold.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
