﻿Module PriceModule
    Public intTotal As Integer
End Module
