﻿Public Class ConferenceOptions

End Class