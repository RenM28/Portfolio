﻿Module KeynoteModule
    Public g_blnDINNER_AND_KEYNOTE As Boolean = False 'keeps track of whether user wants to have dinner and keynote address
    Public g_strSELECTED_WORKSHOP As String           'keeps track of selected workshop
End Module
