﻿Public Class ConferenceOptionsForm
    Const intREGISTRATION As Integer = 895
    Const intDINNER_AND_ADDRESS As Integer = 30
    Const intE_COMMERCE As Integer = 295
    Const intFUTURE_OF_WEB As Integer = 295
    Const intVISUAL_BASIC As Integer = 395
    Const intNETWORK_SECURITY As Integer = 395

    'inputs: workshop name with dollar amount at end as string
    'outputs: workshop name without dollar amount at end as string
    'This function takes in a workshop name as displayed in the listbox and removes the dollar amount so that the customer
    'will only see which workshop they selected in their registration record
    Private Function RemoveDollarAmount(ByVal strWorskhopWithDollarAmount As String) As String
        Dim strPosition As String
        strPosition = strWorskhopWithDollarAmount.IndexOf("$", 0) 'finds where dollar sign is
        Return strWorskhopWithDollarAmount.Remove(strPosition, 4) 'everything past dollar sign
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Dim strWorkshop As String

        If chkRegistration.Checked = True Then
            intTotal = intREGISTRATION
            If chkDinnerAndKeynote.Checked = True Then
                intTotal += intDINNER_AND_ADDRESS
                g_blnDINNER_AND_KEYNOTE = True
            Else
                g_blnDINNER_AND_KEYNOTE = False
            End If
            If lstWorkshops.SelectedIndex = 0 Then
                intTotal += intE_COMMERCE
                strWorkshop = lstWorkshops.Items(0)
                g_strSELECTED_WORKSHOP = RemoveDollarAmount(strWorkshop)
            End If
            If lstWorkshops.SelectedIndex = 1 Then
                intTotal += intFUTURE_OF_WEB
                strWorkshop = lstWorkshops.Items(1)
                g_strSELECTED_WORKSHOP = RemoveDollarAmount(strWorkshop)
            End If
            If lstWorkshops.SelectedIndex = 2 Then
                intTotal += intVISUAL_BASIC
                strWorkshop = lstWorkshops.Items(2)
                g_strSELECTED_WORKSHOP = RemoveDollarAmount(strWorkshop)
            End If
            If lstWorkshops.SelectedIndex = 3 Then
                intTotal += intNETWORK_SECURITY
                strWorkshop = lstWorkshops.Items(3)
                g_strSELECTED_WORKSHOP = RemoveDollarAmount(strWorkshop)
            End If
            Me.Close()
        Else
            MessageBox.Show("Please select Conference Registration before add-ons.")
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        chkDinnerAndKeynote.Checked = False
        g_blnDINNER_AND_KEYNOTE = False
        chkRegistration.Checked = False
        g_strSELECTED_WORKSHOP = String.Empty
        intTotal = 0
        lstWorkshops.SelectedIndex = -1
    End Sub
End Class