﻿Imports System.IO

Public Class MainForm
    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Dim frmOptions As New ConferenceOptionsForm
        frmOptions.ShowDialog()
        lblTotal.Text = intTotal.ToString("c")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtName.Clear()
        txtCompany.Clear()
        txtAddress.Clear()
        txtCity.Clear()
        txtPhone.Clear()
        txtEmail.Clear()
        txtState.Clear()
        txtZip.Clear()
        lblTotal.Text = "$0.00"
        txtName.Focus()
        g_blnDINNER_AND_KEYNOTE = False
        g_strSELECTED_WORKSHOP = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strFILENAME As String           'file to be written to
        Dim conferenceFile As StreamWriter  'object variable

        strFILENAME = InputBox("Enter the name of the file where you'd like to save the registration record.")
        If strFILENAME <> "" Then 'if the user does not hit cancel
            Try
                'open the file
                conferenceFile = File.CreateText(strFILENAME)
                conferenceFile.WriteLine("Conference Registration------------------------------------")
                conferenceFile.WriteLine("Name: " & Space(22) & txtName.Text)
                conferenceFile.WriteLine("Phone: " & Space(21) & txtPhone.Text)
                conferenceFile.WriteLine("Company: " & Space(19) & txtCompany.Text)
                conferenceFile.WriteLine("Email: " & Space(21) & txtEmail.Text)
                conferenceFile.WriteLine("Address: " & Space(19) & txtAddress.Text & ", " & txtState.Text & " " & txtZip.Text)
                If g_blnDINNER_AND_KEYNOTE Then
                    conferenceFile.WriteLine("Attending Keynote Address")
                End If
                conferenceFile.WriteLine("Workshop: " & Space(18) & g_strSELECTED_WORKSHOP)
                conferenceFile.WriteLine("Total Fees: " & Space(16) & lblTotal.Text)

                conferenceFile.Close()
            Catch ex As Exception
                MessageBox.Show("Please enter a valid file name.")
                e.Cancel = True
            End Try
        Else 'if they do hit cancel, will be asked if they really want to exit without saving results
            If MessageBox.Show("Are you sure you want to cancel without saving the results?", "Confirm", MessageBoxButtons.YesNo) =
                Windows.Forms.DialogResult.Yes Then
                e.Cancel = False
            Else
                e.Cancel = True
            End If
        End If
    End Sub
End Class
