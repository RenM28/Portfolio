﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Changes format of columns 2-4 to be 2 decimal places :)
        Me.dgvKayakInfo.Columns(1).DefaultCellStyle.Format = "n2"
        Me.dgvKayakInfo.Columns(2).DefaultCellStyle.Format = "n2"
        Me.dgvKayakInfo.Columns(3).DefaultCellStyle.Format = "n2"
        'TODO: This line of code loads data into the 'RentalPricesDataSet.RentalPrices' table. You can move, or remove it, as needed.
        Me.RentalPricesTableAdapter.Fill(Me.RentalPricesDataSet.RentalPrices)

    End Sub
End Class
