﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblDirections = New System.Windows.Forms.Label()
        Me.pnlGray = New System.Windows.Forms.Panel()
        Me.lblNumClubMembers = New System.Windows.Forms.Label()
        Me.btnRemoveStudent = New System.Windows.Forms.Button()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.lstClubMemList = New System.Windows.Forms.ListBox()
        Me.lstGenStudentList = New System.Windows.Forms.ListBox()
        Me.lblClubMembers = New System.Windows.Forms.Label()
        Me.lblGenStudents = New System.Windows.Forms.Label()
        Me.pnlGray.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDirections
        '
        Me.lblDirections.Location = New System.Drawing.Point(23, 25)
        Me.lblDirections.Name = "lblDirections"
        Me.lblDirections.Size = New System.Drawing.Size(693, 44)
        Me.lblDirections.TabIndex = 0
        Me.lblDirections.Text = resources.GetString("lblDirections.Text")
        '
        'pnlGray
        '
        Me.pnlGray.BackColor = System.Drawing.SystemColors.ControlLight
        Me.pnlGray.Controls.Add(Me.lblNumClubMembers)
        Me.pnlGray.Controls.Add(Me.btnRemoveStudent)
        Me.pnlGray.Controls.Add(Me.btnAddStudent)
        Me.pnlGray.Controls.Add(Me.lstClubMemList)
        Me.pnlGray.Controls.Add(Me.lstGenStudentList)
        Me.pnlGray.Controls.Add(Me.lblClubMembers)
        Me.pnlGray.Controls.Add(Me.lblGenStudents)
        Me.pnlGray.Location = New System.Drawing.Point(26, 91)
        Me.pnlGray.Name = "pnlGray"
        Me.pnlGray.Size = New System.Drawing.Size(690, 336)
        Me.pnlGray.TabIndex = 1
        '
        'lblNumClubMembers
        '
        Me.lblNumClubMembers.AutoSize = True
        Me.lblNumClubMembers.Location = New System.Drawing.Point(588, 246)
        Me.lblNumClubMembers.Name = "lblNumClubMembers"
        Me.lblNumClubMembers.Size = New System.Drawing.Size(78, 17)
        Me.lblNumClubMembers.TabIndex = 6
        Me.lblNumClubMembers.Text = "0 members"
        '
        'btnRemoveStudent
        '
        Me.btnRemoveStudent.Location = New System.Drawing.Point(572, 122)
        Me.btnRemoveStudent.Name = "btnRemoveStudent"
        Me.btnRemoveStudent.Size = New System.Drawing.Size(108, 104)
        Me.btnRemoveStudent.TabIndex = 5
        Me.btnRemoveStudent.Text = "Remove selected member"
        Me.btnRemoveStudent.UseVisualStyleBackColor = True
        '
        'btnAddStudent
        '
        Me.btnAddStudent.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAddStudent.FlatAppearance.BorderSize = 3
        Me.btnAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddStudent.Location = New System.Drawing.Point(247, 122)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(106, 104)
        Me.btnAddStudent.TabIndex = 4
        Me.btnAddStudent.Text = "Add selected student"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'lstClubMemList
        '
        Me.lstClubMemList.FormattingEnabled = True
        Me.lstClubMemList.ItemHeight = 16
        Me.lstClubMemList.Location = New System.Drawing.Point(362, 53)
        Me.lstClubMemList.Name = "lstClubMemList"
        Me.lstClubMemList.Size = New System.Drawing.Size(200, 244)
        Me.lstClubMemList.TabIndex = 3
        '
        'lstGenStudentList
        '
        Me.lstGenStudentList.FormattingEnabled = True
        Me.lstGenStudentList.ItemHeight = 16
        Me.lstGenStudentList.Items.AddRange(New Object() {"Edison, Annie", "Winger, Jeff", "Barnes, Troy", "Perry, Britta", "Nadir, Abed", "Hawthorne, Pierce", "Bennett, Shirley", "Chang, Ben", "Pelton, Craig"})
        Me.lstGenStudentList.Location = New System.Drawing.Point(35, 53)
        Me.lstGenStudentList.Name = "lstGenStudentList"
        Me.lstGenStudentList.Size = New System.Drawing.Size(200, 244)
        Me.lstGenStudentList.TabIndex = 2
        '
        'lblClubMembers
        '
        Me.lblClubMembers.AutoSize = True
        Me.lblClubMembers.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClubMembers.Location = New System.Drawing.Point(359, 28)
        Me.lblClubMembers.Name = "lblClubMembers"
        Me.lblClubMembers.Size = New System.Drawing.Size(171, 18)
        Me.lblClubMembers.TabIndex = 1
        Me.lblClubMembers.Text = "Club Membership List"
        '
        'lblGenStudents
        '
        Me.lblGenStudents.AutoSize = True
        Me.lblGenStudents.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGenStudents.Location = New System.Drawing.Point(32, 28)
        Me.lblGenStudents.Name = "lblGenStudents"
        Me.lblGenStudents.Size = New System.Drawing.Size(161, 18)
        Me.lblGenStudents.TabIndex = 0
        Me.lblGenStudents.Text = "General Student List"
        '
        'Form1
        '
        Me.AcceptButton = Me.btnAddStudent
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(746, 456)
        Me.Controls.Add(Me.pnlGray)
        Me.Controls.Add(Me.lblDirections)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Adding Students to a Club"
        Me.pnlGray.ResumeLayout(False)
        Me.pnlGray.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblDirections As Label
    Friend WithEvents pnlGray As Panel
    Friend WithEvents lblNumClubMembers As Label
    Friend WithEvents btnRemoveStudent As Button
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents lstClubMemList As ListBox
    Friend WithEvents lstGenStudentList As ListBox
    Friend WithEvents lblClubMembers As Label
    Friend WithEvents lblGenStudents As Label
End Class
