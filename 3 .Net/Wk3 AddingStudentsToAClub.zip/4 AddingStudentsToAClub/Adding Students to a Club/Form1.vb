﻿Public Class Form1
    Dim intNumClubMembers As Integer = 0 'initializes number of students in club
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddStudent.Click
        'if a name is selected the following will run
        If lstGenStudentList.SelectedIndex <> -1 Then
            Dim intCount As Integer 'initializes count variable
            For intCount = 0 To lstGenStudentList.Items.Count - 1 'iterates through all students in general list
                'if the index of selected student matches the count variable additional conditional is checked
                If lstGenStudentList.SelectedIndex = intCount Then
                    'if the club member list already contains the selection, error message will be shown
                    If lstClubMemList.Items.Contains(lstGenStudentList.SelectedItem) Then
                        MessageBox.Show("This student is already in the club. Please choose someone else.")
                    Else 'otherwise student will be added to club member list
                        lstClubMemList.Items.Add(lstGenStudentList.Items(intCount))
                        intNumClubMembers += 1 'adds 1 student to running total of club members
                        'Following conditional accounts for grammar difference between 1 member and x members
                        If intNumClubMembers = 0 Or intNumClubMembers > 1 Then
                            lblNumClubMembers.Text = intNumClubMembers.ToString() & " members"
                        Else
                            lblNumClubMembers.Text = intNumClubMembers.ToString() & " member"
                        End If
                    End If
                End If
            Next
        Else
            'Error message shown if user does not select a student to add
            MessageBox.Show("Please select a student to add.")
        End If
    End Sub

    Private Sub btnRemoveStudent_Click(sender As Object, e As EventArgs) Handles btnRemoveStudent.Click
        'if name is selected in club list, code will run
        If lstClubMemList.SelectedIndex <> -1 Then
            Dim intCount As Integer 'initializes count
            For intCount = 0 To lstClubMemList.Items.Count - 1 'iterates through all students in club member list
                'if index of club memeber selected matches current count value, conditional is executed
                If lstClubMemList.SelectedIndex = intCount Then
                    lstClubMemList.Items.Remove(lstClubMemList.Items(intCount)) 'removes selected club member
                    intNumClubMembers -= 1 'subtracts 1 student from running total of club members
                    'once again, accounts for grammar differences
                    If intNumClubMembers = 0 Or intNumClubMembers > 1 Then
                        lblNumClubMembers.Text = intNumClubMembers.ToString() & " members"
                    Else
                        lblNumClubMembers.Text = intNumClubMembers.ToString() & " member"
                    End If
                End If
            Next
        Else
            'if user does not select student to remove, shows error
            MessageBox.Show("Please select a student to remove.")
        End If
    End Sub
End Class
